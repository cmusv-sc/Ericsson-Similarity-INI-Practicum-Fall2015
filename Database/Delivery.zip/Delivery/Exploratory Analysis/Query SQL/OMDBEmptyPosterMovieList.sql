﻿SELECT movieid as Movielen_id, imdbid as IMDB_ID, title as Movie_Title
From data20m
WHERE poster = ''
